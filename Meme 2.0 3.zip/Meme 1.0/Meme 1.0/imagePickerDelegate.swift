//
//  imagePickerDelegate.swift
//  Meme 1.0
//
//  Created by Samarth Navale on 02/01/17.
//  Copyright © 2017 Samarth Navale. All rights reserved.
//

import Foundation
import UIKit

class imagePickerDelegate : NSObject, UIImagePickerControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [String : Any]){
        if let image = info[/* TODO: Dictionary Key Goes Here */UIImagePickerControllerOriginalImage] as? UIImage {
            imageView.image = image
        }
    }
    
}

