//
//  SentMemesTableViewController.swift
//  Meme 1.0
//
//  Created by Samarth Navale on 15/01/17.
//  Copyright © 2017 Samarth Navale. All rights reserved.
//

import Foundation
import UIKit

// MARK: - ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate

class SentMemesTableViewController: UITableViewController {
    @IBOutlet var add: UIBarButtonItem!
    
       override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
    }
    // MARK: Properties
    
    // Get ahold of some villains, for the table
    // This is an array of Villain instances
    // MARK: Table View Data Source
    var memes : [Meme]{
       return (UIApplication.shared.delegate as! AppDelegate).memes
    }
    
    override func viewDidLoad() {
      super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
    }


    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.memes.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "SentMemesTableViewCell",for: indexPath) as UITableViewCell
        let meme = self.memes[(indexPath as NSIndexPath).row]
        
        // Set the name and image
        cell.textLabel?.text = meme.topText
        cell.imageView?.image = meme.memedImage
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let detailController = self.storyboard!.instantiateViewController(withIdentifier: "MemeDetailViewController") as! MemeDetailViewController
        detailController.mem = self.memes[(indexPath as NSIndexPath).row]
        self.navigationController!.pushViewController(detailController, animated: true)
    }

}
