//
//  ViewController.swift
//  Meme 1.0
//
//  Created by Samarth Navale on 02/01/17.
//  Copyright © 2017 Samarth Navale. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextFieldDelegate {
    
    @IBOutlet weak var cancel: UIBarButtonItem!
    @IBOutlet weak var toolbar: UIToolbar!
    @IBOutlet weak var share: UIBarButtonItem!
    @IBOutlet weak var cameraButton: UIBarButtonItem!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var textField1: UITextField!
    @IBOutlet weak var textField2: UITextField!
    
    //initialize the delegates
    
    
    let top = topDelegate()
    let bottom = bottomDelegate()
    
    
    
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    //adding the meme attributes to the text
    let memeTextAttributes:[String:Any] = [
        NSStrokeColorAttributeName: UIColor.black/* TODO: fill in appropriate UIColor */,
        NSForegroundColorAttributeName: UIColor.white /* TODO: fill in appropriate UIColor */,
        NSFontAttributeName: UIFont(name: "HelveticaNeue-CondensedBlack", size: 35)!,
        NSStrokeWidthAttributeName: -3.3 /* TODO: fill in appropriate Float */]
    
    func configureTextField(textField: UITextField,initialDefaultText: String){
        textField.text = "\(initialDefaultText)"
        
        //assigning the attributes to the text in the textField
        textField.defaultTextAttributes = memeTextAttributes
        
       
        
        
        //Text should be center-aligned.
        textField.textAlignment = .center
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //disable the share buttom
        self.share.isEnabled = false
        
       
        configureTextField(textField: textField1, initialDefaultText: "top")
        configureTextField(textField: textField2, initialDefaultText: "bottom")
        // assigning the top and bottom delegates to the textField
        self.textField1.delegate = top
        self.textField2.delegate = bottom
        
        //image at the imageView is initialized to nil
        
        self.imageView.image = nil
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
        
        //camera is disabled if the camera source type is not available
        cameraButton.isEnabled = UIImagePickerController.isSourceTypeAvailable(.camera)
        
        subscribeToKeyboardNotifications()
        subscribeToKeyboardHideNotifications()
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        super.viewWillDisappear(animated)
        
        unsubscribeFromKeyboardNotifications()
        unsubscribeFromKeyboardHideNotifications()
    }
    
    
    func pickAnImageFromSource (source: UIImagePickerControllerSourceType){
        let pickController = UIImagePickerController()
        pickController.delegate = self
        pickController.sourceType = source
        self.present(pickController, animated: true, completion: nil)
        
        
    }
    //picking up images
    @IBAction func pickAnImage(_ sender: Any) {
        pickAnImageFromSource(source: .photoLibrary)
    }
    //opening the camera
    @IBAction func pickAnImageFromCamera(_ sender: Any) {
        pickAnImageFromSource(source: .camera)
        
        dismiss(animated: true, completion: nil)
        
    }
    //getting access to images using imagepicker method
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [String : Any]){
        
        if let image = info[UIImagePickerControllerEditedImage] as? UIImage {
            imageView.image = image
        } else if let image = info[UIImagePickerControllerOriginalImage] as? UIImage {
            imageView.image = image
        } else {
            imageView.image = nil
            print("something went wrong")
        }
        dismiss(animated: true, completion: nil)
        if imageView.image != nil{
            self.share.isEnabled = true
        }
    }
    
    //method to dismiss the imagepicker
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController){
        dismiss(animated: true, completion: nil)
    }
    //shifting the view when keyboard shows up
    func keyboardWillShow(_ notification:Notification) {
        if textField2.isFirstResponder {
            view.frame.origin.y -= getKeyboardHeight(notification)
        }
        
    }
    // shifting the view back to its default position when the editing ends and return key is pressed
    func keyboardWillHide(_ notification:Notification) {
        
        view.frame.origin.y = 0  }
    
    // this method provides the height of keyboard
    func getKeyboardHeight(_ notification:Notification) -> CGFloat {
        
        let userInfo = notification.userInfo
        let keyboardSize = userInfo![UIKeyboardFrameEndUserInfoKey] as! NSValue // of CGRect
        return keyboardSize.cgRectValue.height
    }
    
    //subscribing to the keyboard notification
    func subscribeToKeyboardNotifications() {
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: .UIKeyboardWillShow, object: nil)
    }
    //subscribe to the keyborad hide notification
    func subscribeToKeyboardHideNotifications() {
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: .UIKeyboardWillHide, object: nil)
    }
    
    
    
    //unsubscribing the keyboard notification
    func unsubscribeFromKeyboardNotifications() {
        
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
    }
    
    func unsubscribeFromKeyboardHideNotifications() {
        
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
    }
    
   
    
    func save() {
        let meme = Meme(topText: textField1.text!, bottomText: textField2.text!, originalImage: imageView.image!, memedImage: generateMemedImage())
        //var appDelegate : AppDelegate
            
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.memes.append(meme)
    }
    
    //combining the image and the text and generating a meme image
    func generateMemedImage() -> UIImage {
        
        // TODO: Hide toolbar and navbar
        self.toolbar.isHidden = true
        
        // Render view to an image
        UIGraphicsBeginImageContext(self.view.frame.size)
        view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
        let memedImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        // TODO: Show toolbar and navbar
        self.toolbar.isHidden = false
        //navigationController?.isToolbarHidden = false
        
        return memedImage
    }
    
    
    
    
    
    // this action to the share button which opens the activity viewcontoller to share the meme image
    @IBAction func experiment(_ sender: Any) {
        
        
        let memedImage = generateMemedImage()
        
        
        
        let controller = UIActivityViewController(activityItems: [memedImage], applicationActivities: nil)
        self.present(controller, animated: true, completion: nil)
        
        controller.completionWithItemsHandler = {(activityType,completed,returnedItems,activityError) -> Void in
            self.save()
            self.dismiss(animated: true, completion: nil)
        }
        
    }
    // when cancel button is pressed the image dissapears from image view and the textfield returns to its default value
    @IBAction func cancel(_ sender: Any) {
        viewDidLoad()
    }
    
}
