//
//  topDelegate.swift
//  Meme 1.0
//
//  Created by Samarth Navale on 06/01/17.
//  Copyright © 2017 Samarth Navale. All rights reserved.
//

import Foundation
import UIKit

class topDelegate : NSObject,UITextFieldDelegate {
    
    
    func textFieldDidBeginEditing(_ textField1: UITextField) {
        textField1.text = ""
    }
    
    func textFieldShouldReturn(_ textField1: UITextField) -> Bool {
        textField1.resignFirstResponder()
        
        return true;
    }
}
