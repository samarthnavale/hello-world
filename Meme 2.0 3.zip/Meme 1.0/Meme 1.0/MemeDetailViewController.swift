//
//  MemeDetailViewController.swift
//  Meme 1.0
//
//  Created by Samarth Navale on 15/01/17.
//  Copyright © 2017 Samarth Navale. All rights reserved.
//

import Foundation
import UIKit

// MARK: - VillainDetailViewController: UIViewController

class MemeDetailViewController: UIViewController {
    
    @IBOutlet var label: UILabel!
    // MARK: Properties
    
    @IBOutlet weak var imageView: UIImageView!
    
    var mem: Meme!
    
    // MARK: Outlets
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.label.text = self.mem.topText
        //self.tabBarController?.tabBar.isHidden = true
        self.imageView!.image = mem.memedImage
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        //self.tabBarController?.tabBar.isHidden = false
    }

    
    // MARK: Life Cycle
    

}
