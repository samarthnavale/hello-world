//
//  Meme.swift
//  Meme 1.0
//
//  Created by Samarth Navale on 15/01/17.
//  Copyright © 2017 Samarth Navale. All rights reserved.
//

import Foundation
import UIKit


struct Meme {
    let topText : String
    let bottomText : String
    let originalImage : UIImage
    let memedImage : UIImage

}
