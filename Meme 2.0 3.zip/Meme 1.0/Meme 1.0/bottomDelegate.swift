//
//  buttomDelegate.swift
//  Meme 1.0
//
//  Created by Samarth Navale on 06/01/17.
//  Copyright © 2017 Samarth Navale. All rights reserved.
//

import Foundation
import UIKit


class bottomDelegate : NSObject,UITextFieldDelegate {
    

    func textFieldDidBeginEditing(_ textField2: UITextField) {
        textField2.text = ""

    }
    
    func textFieldShouldReturn(_ textField2: UITextField) -> Bool {
        textField2.resignFirstResponder()
        return true;
}
}
  
