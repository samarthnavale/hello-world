//
//  SetMemesCollectionViewCell.swift
//  Meme 1.0
//
//  Created by Samarth Navale on 14/01/17.
//  Copyright © 2017 Samarth Navale. All rights reserved.
//

import Foundation
import UIKit

class SentMemesCollectionViewCell : UICollectionViewCell {
    
    
    
    @IBOutlet weak var SentMemeImageView: UIImageView!
    
    
}
